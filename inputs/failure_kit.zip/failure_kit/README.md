# CCTV failure kit

Bangkok BMA traffic cameras, 100 cameras, 25-31 Aug 2026, one capture about every
10 minutes between 06:00 and 21:00 (no overnight images). Times are Bangkok local.
Generated 2026-11-16 13:00 UTC by `src/pipeline/export_failure_kit.py`.

## Files

### slots.csv: one row per capture slot (63,129 rows)
Every image in the dataset (61,319) plus one row per **missing** slot (1,810),
i.e. a 10-minute slot with no image at all. Use it as the denominator for failure rates.

| column | meaning |
|---|---|
| camera_id | BMA camera number (join key to cameras.csv) |
| slot_at | capture time. For missing slots it is estimated (gap start + 10 min steps) |
| time_estimated | True for missing slots |
| failure_type | `ok`, `missing`, `offline placeholder`, `duplicate frame`, `decode artifact`, `test pattern`, `partial corruption`, `obstructed view` |
| failure_detail | sub-kind for hand-checked frames: `green block`, `streak smear`, `object over lens` (else empty) |
| is_failure | failure_type != ok |
| rel_path | image path `<camera_id>/<file>.jpg` inside `cctv_images/` (empty for missing) |
| date, hour, weekday | from slot_at |
| time_bucket | Morning rush 6-9, Midday 9-16, Evening rush 16-19, Evening 19-21 |
| lighting | Day / Twilight / Dark from Bangkok sunrise and sunset |
| episode_id, outage_id | link to episodes.csv (empty for ok slots) |

### episodes.csv: one row per failure episode (1,046 rows)
An episode is a run of consecutive slots with the same failure type on one camera and
day. An outage (`outage_id`) groups adjacent episodes of any type with no valid frame
between them (e.g. missing, then placeholder, then missing again on 27 Aug).

| column | meaning |
|---|---|
| start, end | first failed slot; next observation (or 21:00 window close) |
| duration_min | end - start. For `missing` it runs from the first lost slot to the next frame, so it is the gap minus the normal 10 min (a 1-slot gap lasts ~5-10 min) |
| n_slots | capture slots lost in the episode |
| open_censored / close_censored | episode touches 06:00 / 21:00, may have started earlier or lasted longer |
| district | from GPS |

### cameras.csv: one row per camera (100 rows)
Location (Thai and English), GPS, district, `ip_address` and `subnet` (first 3 octets:
cameras on one subnet may share a network link, worth testing for "fail together"),
slot counts per failure type, `failure_rate`, episode and outage counts, longest outage.

## Failure types
Search or filter on the exact `failure_type` value (first column). In Excel: Data > Filter on
`failure_type`. In pandas: `slots[slots["failure_type"] == "partial corruption"]`.
`failure_detail` in slots.csv gives the sub-kind where one exists.

| failure_type | slots | episodes | cameras | top cameras (slots) | found by | meaning |
|---|---|---|---|---|---|---|
| `missing` | 1,810 | 434 | 100 | 1076 (26), 1078 (25), 88 (24), 36 (22) | time gap between captures | no image at all for the slot (two captures more than 15 min apart). Could be the camera or the dataset collector |
| `offline placeholder` | 504 | 485 | 100 | 603 (10), 939 (10), 11 (9), 233 (8) | frame size | plain white 400x266 frame served when a camera is down. Appears in one short window each morning (07:15-08:45, time shifts by day) |
| `duplicate frame` | 553 | 65 | 20 | 150 (124), 938 (98), 206 (95), 939 (95) | pixel hash | frozen stream: same pixels as an earlier frame. The first copy counts as ok, so a freeze starts about 10 min before its first duplicate |
| `decode artifact` | 35 | 33 | 2 | 169 (26), 206 (9) | share of mid-grey pixels > 0.5 | flat grey frame with ghost vehicles (lost video keyframe) |
| `test pattern` | 33 | 3 | 2 | 432 (17), 1804 (16) | frame size | colour bars 246x205 |
| `partial corruption` | 30 | 25 | 5 | 500 (13), 630 (10), 332 (5), 32 (1) | checked by eye | top of the frame is fine, the rest is lost: a flat green block (`failure_detail` = green block) or vertical streaks / smeared rows (streak smear). Lower bound: no rule finds these reliably |
| `obstructed view` | 1 | 1 | 1 | 68 (1) | checked by eye | something covers the lens |
| `ok` | 60,163 | | 100 | | | normal frame |

## Caveats
- One week only (Tue 25 - Mon 31 Aug), 06:00-21:00 only.
- English names in cctv_info are unreliable for 17 cameras; trust the Thai `location`.
- 27 Aug 06:00-09:00: city-wide outage on 98 cameras; treat it as one event, not 98.
- Every invalid frame was checked by eye (2026-11-16), plus valid frames near each rule
  (dark, bright, low contrast, near-grey, black-and-white, grey/flat bands, repeated rows).
  Near-duplicate frames and frames next to a failure were not reviewed.
- `missing` means two captures more than 15 min apart; a capture late by less is not counted.
